# 02-Inspercoin

Veja o enunciado em https://insper.github.io/SistemasHardwareSoftware/labs/processos/

Utilize como base o repositório de referência indicado no enunciado. Você pode copiá-lo todo aqui para esta parta e alterar o que achar necessário (pode alterar o que quiser, desde que funcione conforme solicitado).

Confira o prazo e como entregar no enunciado.

Seu programa deve compilar com:
```
make rebuild
```
E como resultado, deve gerar um executável `inspercoin`. Então, crie um makefile ou copie o contido no repositório de referência.
