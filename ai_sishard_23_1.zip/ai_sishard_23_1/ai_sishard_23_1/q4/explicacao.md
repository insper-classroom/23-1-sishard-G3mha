
# Explicação

Deixe aqui a sua explicação do que a função `ex4` faz. Faça uma explicação breve e direta (uma frase, uma ou duas linhas).

Ex: se você acha que é uma função que calcula fatorial, basta escrever aqui "Calcula fatorial e retorna utilizando..."

Sua resposta: