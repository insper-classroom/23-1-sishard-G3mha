#include <stdio.h>

// Implemente aqui uma funcao chamada ex3_solucao

int ex3_solucao() {
    
}